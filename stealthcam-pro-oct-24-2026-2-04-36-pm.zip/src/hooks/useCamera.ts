/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { CapturedMedia, saveMediaItem } from '../utils/storage';
import {
  playShutterSound,
  playCountdownBeep,
  playRecordStartSound,
  playRecordStopSound,
} from '../utils/audio';
import { TimerSettings } from '../utils/timer';

export interface CameraState {
  stream: MediaStream | null;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  isLive: boolean;
  isSimulated: boolean;
  hasPermission: boolean;
  isPermissionDenied: boolean;
  error: string | null;
  devices: MediaDeviceInfo[];
  activeDeviceId: string;
  facingMode: 'user' | 'environment';
  isRecording: boolean;
  recordingDuration: number;
  isCountingDown: boolean;
  countdownSecondsRemaining: number;
  micEnabled: boolean;
  isFlashActive: boolean;
}

export function useCamera(
  settings: TimerSettings,
  onCaptureCompleted?: (item: CapturedMedia) => void
) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordIntervalRef = useRef<number | null>(null);
  const countdownIntervalRef = useRef<number | null>(null);
  const simCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const simAnimIdRef = useRef<number | null>(null);

  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [isPermissionDenied, setIsPermissionDenied] = useState<boolean>(false);
  const [isLive, setIsLive] = useState<boolean>(false);
  const [isSimulated, setIsSimulated] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [activeDeviceId, setActiveDeviceId] = useState<string>('');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [micEnabled, setMicEnabled] = useState<boolean>(true);

  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);
  const [isCountingDown, setIsCountingDown] = useState<boolean>(false);
  const [countdownSecondsRemaining, setCountdownSecondsRemaining] = useState<number>(0);
  const [isFlashActive, setIsFlashActive] = useState<boolean>(false);

  // Settings ref to access current timer configurations in callbacks
  const settingsRef = useRef(settings);
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Clean up streams & recorders
  const stopTracks = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (simAnimIdRef.current) {
      cancelAnimationFrame(simAnimIdRef.current);
      simAnimIdRef.current = null;
    }
  }, []);

  // Setup animated simulated canvas camera stream
  const startSimulatedFeed = useCallback(() => {
    stopTracks();
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    simCanvasRef.current = canvas;
    const ctx = canvas.getContext('2d');

    let angle = 0;
    const drawSim = () => {
      if (!ctx) return;
      angle += 0.03;

      // Dark futuristic studio background
      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(0.5, '#1e1b4b');
      grad.addColorStop(1, '#020617');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 64) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Rotating aperture graphic
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(angle);

      // Outer rings
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, 160, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(236, 72, 153, 0.8)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 120 + Math.sin(angle * 3) * 15, 0, Math.PI * 2);
      ctx.stroke();

      // Crosshair
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-30, 0);
      ctx.lineTo(30, 0);
      ctx.moveTo(0, -30);
      ctx.lineTo(0, 30);
      ctx.stroke();

      ctx.restore();

      // Info banner
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(40, 40, 360, 100);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 20px monospace';
      ctx.fillText('● SIMULATED SENSOR ACTIVE', 60, 75);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px monospace';
      const now = new Date();
      ctx.fillText(`FPS: 30 | RES: 1280x720 | 16:9`, 60, 100);
      ctx.fillText(`UTC: ${now.toISOString().substring(11, 23)}`, 60, 122);

      simAnimIdRef.current = requestAnimationFrame(drawSim);
    };

    drawSim();

    const stream = canvas.captureStream(30);
    streamRef.current = stream;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }
    setIsLive(true);
    setIsSimulated(true);
    setHasPermission(true);
    setIsPermissionDenied(false);
    setError(null);
  }, [stopTracks]);

  // Request real camera stream
  const startCamera = useCallback(
    async (preferSimulated = false) => {
      if (preferSimulated) {
        startSimulatedFeed();
        return;
      }

      stopTracks();
      setError(null);

      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('MediaDevices API not supported on this browser');
        }

        const constraints: MediaStreamConstraints = {
          video: activeDeviceId
            ? { deviceId: { exact: activeDeviceId } }
            : {
                facingMode: facingMode,
                width: { ideal: 1920 },
                height: { ideal: 1080 },
              },
          audio: micEnabled,
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }

        setHasPermission(true);
        setIsPermissionDenied(false);
        setIsLive(true);
        setIsSimulated(false);

        // List media devices
        try {
          const devs = await navigator.mediaDevices.enumerateDevices();
          const videoDevs = devs.filter((d) => d.kind === 'videoinput');
          setDevices(videoDevs);
        } catch {}
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : 'Camera access failed';
        console.warn('Real camera stream failed:', errorMsg);
        setError(errorMsg);
        // If real camera is absent or denied, smoothly fall back to simulated stream
        startSimulatedFeed();
      }
    },
    [activeDeviceId, facingMode, micEnabled, stopTracks, startSimulatedFeed]
  );

  useEffect(() => {
    startCamera();
    return () => {
      stopTracks();
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    };
  }, [startCamera, stopTracks]);

  // Switch facing mode (Front / Back)
  const toggleFacingMode = useCallback(() => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  }, []);

  // Perform single photo capture from current video frame
  const capturePhotoImmediate = useCallback(async (): Promise<CapturedMedia | null> => {
    const video = videoRef.current;
    if (!video) return null;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Draw the current video frame
    ctx.drawImage(video, 0, 0, width, height);

    // Trigger visual flash animation
    setIsFlashActive(true);
    setTimeout(() => setIsFlashActive(false), 200);

    // Shutter audio
    playShutterSound(settingsRef.current.soundFeedback);

    return new Promise((resolve) => {
      canvas.toBlob(
        async (blob) => {
          if (!blob) {
            resolve(null);
            return;
          }
          const id = `photo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          const timestamp = Date.now();
          const item: CapturedMedia = {
            id,
            type: 'photo',
            url: URL.createObjectURL(blob),
            blob,
            name: `Photo_${new Date(timestamp).toISOString().replace(/[:.]/g, '-')}.png`,
            timestamp,
            width,
            height,
            sizeBytes: blob.size,
          };

          await saveMediaItem(item);
          if (onCaptureCompleted) {
            onCaptureCompleted(item);
          }
          resolve(item);
        },
        'image/png',
        0.95
      );
    });
  }, [onCaptureCompleted]);

  // Handle Photo Capture with Timer & Burst support
  const triggerPhotoCapture = useCallback(() => {
    if (isCountingDown || isRecording) return;
    const delay = settingsRef.current.photoCountdownSeconds;

    if (delay <= 0) {
      // Instant snap
      const burstCount = settingsRef.current.burstCount || 1;
      if (burstCount <= 1) {
        capturePhotoImmediate();
      } else {
        // Multi-shot burst
        let shotsTaken = 0;
        const interval = setInterval(() => {
          capturePhotoImmediate();
          shotsTaken++;
          if (shotsTaken >= burstCount) {
            clearInterval(interval);
          }
        }, settingsRef.current.burstIntervalMs || 600);
      }
      return;
    }

    // Countdown timer active
    setIsCountingDown(true);
    let remaining = delay;
    setCountdownSecondsRemaining(remaining);
    playCountdownBeep(remaining === 1, settingsRef.current.soundFeedback);

    countdownIntervalRef.current = window.setInterval(() => {
      remaining -= 1;
      setCountdownSecondsRemaining(remaining);

      if (remaining > 0) {
        playCountdownBeep(remaining === 1, settingsRef.current.soundFeedback);
      } else {
        if (countdownIntervalRef.current) {
          clearInterval(countdownIntervalRef.current);
          countdownIntervalRef.current = null;
        }
        setIsCountingDown(false);
        capturePhotoImmediate();
      }
    }, 1000);
  }, [isCountingDown, isRecording, capturePhotoImmediate]);

  // Video recording control: Stop Recording
  const stopVideoRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (recordIntervalRef.current) {
      clearInterval(recordIntervalRef.current);
      recordIntervalRef.current = null;
    }
    setIsRecording(false);
    playRecordStopSound(settingsRef.current.soundFeedback);
  }, []);

  // Internal start recording after delay has elapsed
  const startRecordingImmediate = useCallback(() => {
    if (!streamRef.current) return;
    recordedChunksRef.current = [];

    let mimeType = 'video/webm';
    if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')) {
      mimeType = 'video/webm;codecs=vp9,opus';
    } else if (MediaRecorder.isTypeSupported('video/webm')) {
      mimeType = 'video/webm';
    } else if (MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = 'video/mp4';
    }

    try {
      const recorder = new MediaRecorder(streamRef.current, { mimeType });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = async () => {
        const duration = recordingDuration;
        const blob = new Blob(recordedChunksRef.current, { type: mimeType });
        const id = `video_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const timestamp = Date.now();
        const extension = mimeType.includes('mp4') ? 'mp4' : 'webm';
        const item: CapturedMedia = {
          id,
          type: 'video',
          url: URL.createObjectURL(blob),
          blob,
          name: `Video_${new Date(timestamp).toISOString().replace(/[:.]/g, '-')}.${extension}`,
          timestamp,
          duration,
          width: videoRef.current?.videoWidth || 1280,
          height: videoRef.current?.videoHeight || 720,
          sizeBytes: blob.size,
        };

        await saveMediaItem(item);
        if (onCaptureCompleted) {
          onCaptureCompleted(item);
        }
      };

      recorder.start(500); // 500ms chunk slices
      setIsRecording(true);
      setRecordingDuration(0);
      playRecordStartSound(settingsRef.current.soundFeedback);

      // Duration ticker
      let elapsed = 0;
      const maxDuration = settingsRef.current.videoDurationSeconds;
      recordIntervalRef.current = window.setInterval(() => {
        elapsed += 1;
        setRecordingDuration(elapsed);

        // Check if duration limit reached
        if (maxDuration > 0 && elapsed >= maxDuration) {
          stopVideoRecording();
        }
      }, 1000);
    } catch (err) {
      console.error('Failed to start MediaRecorder:', err);
      setIsRecording(false);
    }
  }, [recordingDuration, onCaptureCompleted, stopVideoRecording]);

  // Video recording toggle with start delay
  const triggerVideoRecording = useCallback(() => {
    if (isRecording) {
      stopVideoRecording();
      return;
    }

    if (isCountingDown) {
      // Cancel countdown
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
      setIsCountingDown(false);
      return;
    }

    const delay = settingsRef.current.videoDelaySeconds;
    if (delay <= 0) {
      startRecordingImmediate();
      return;
    }

    // Countdown before video starts
    setIsCountingDown(true);
    let remaining = delay;
    setCountdownSecondsRemaining(remaining);
    playCountdownBeep(remaining === 1, settingsRef.current.soundFeedback);

    countdownIntervalRef.current = window.setInterval(() => {
      remaining -= 1;
      setCountdownSecondsRemaining(remaining);

      if (remaining > 0) {
        playCountdownBeep(remaining === 1, settingsRef.current.soundFeedback);
      } else {
        if (countdownIntervalRef.current) {
          clearInterval(countdownIntervalRef.current);
          countdownIntervalRef.current = null;
        }
        setIsCountingDown(false);
        startRecordingImmediate();
      }
    }, 1000);
  }, [isRecording, isCountingDown, stopVideoRecording, startRecordingImmediate]);

  const cancelCountdown = useCallback(() => {
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    setIsCountingDown(false);
  }, []);

  return {
    videoRef,
    isLive,
    isSimulated,
    hasPermission,
    isPermissionDenied,
    error,
    devices,
    activeDeviceId,
    setActiveDeviceId,
    facingMode,
    toggleFacingMode,
    micEnabled,
    setMicEnabled,
    isRecording,
    recordingDuration,
    isCountingDown,
    countdownSecondsRemaining,
    cancelCountdown,
    isFlashActive,
    triggerPhotoCapture,
    triggerVideoRecording,
    stopVideoRecording,
    startCamera,
    startSimulatedFeed,
  };
}
