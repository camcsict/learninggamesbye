/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useTransition } from 'react';
import { useCamera } from './hooks/useCamera';
import { CameraView } from './components/CameraView';
import { ScreenOverlay } from './components/ScreenOverlay';
import { CaptureControls } from './components/CaptureControls';
import { HeaderBar } from './components/HeaderBar';
import { TimerSettingsModal } from './components/TimerSettingsModal';
import { GalleryModal } from './components/GalleryModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import {
  ScreenOverlayMode,
  ButtonVisibilityMode,
  CaptureMode,
  TimerSettings,
  DEFAULT_TIMER_SETTINGS,
  getNextOverlayMode,
} from './utils/timer';
import {
  CapturedMedia,
  loadMediaItems,
  deleteMediaItem,
  clearAllMedia,
} from './utils/storage';

export default function App() {
  const [overlayMode, setOverlayMode] = useState<ScreenOverlayMode>('normal');
  const [buttonVisibility, setButtonVisibility] = useState<ButtonVisibilityMode>('visible');
  const [captureMode, setCaptureMode] = useState<CaptureMode>('photo');
  const [timerSettings, setTimerSettings] = useState<TimerSettings>(DEFAULT_TIMER_SETTINGS);
  const [tapToCapture, setTapToCapture] = useState<boolean>(false);

  const [mediaList, setMediaList] = useState<CapturedMedia[]>([]);
  const [isGalleryOpen, setIsGalleryOpen] = useState<boolean>(false);
  const [isTimerModalOpen, setIsTimerModalOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);
  const [isAndroidInstallOpen, setIsAndroidInstallOpen] = useState<boolean>(false);
  const [isPeeking, setIsPeeking] = useState<boolean>(false);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const { isInstallable, isInstalled, triggerInstallPrompt } = usePWAInstall();

  // New capture callback
  const handleCaptureCompleted = useCallback((item: CapturedMedia) => {
    setMediaList((prev) => [item, ...prev]);
    const toastMsg = item.type === 'photo' ? 'Photo captured!' : 'Video recorded!';
    setFeedbackToast(toastMsg);
    setTimeout(() => setFeedbackToast(null), 2500);
  }, []);

  // Initialize camera hook
  const {
    videoRef,
    isLive,
    isSimulated,
    isRecording,
    recordingDuration,
    isCountingDown,
    countdownSecondsRemaining,
    cancelCountdown,
    isFlashActive,
    triggerPhotoCapture,
    triggerVideoRecording,
    stopVideoRecording,
    toggleFacingMode,
    micEnabled,
    setMicEnabled,
    startCamera,
    startSimulatedFeed,
  } = useCamera(timerSettings, handleCaptureCompleted);

  // Load saved media on mount
  useEffect(() => {
    loadMediaItems().then((items) => {
      setMediaList(items);
    });
  }, []);

  // Main capture trigger based on current capture mode
  const handleMainCapture = useCallback(() => {
    if (captureMode === 'photo') {
      triggerPhotoCapture();
    } else {
      triggerVideoRecording();
    }
  }, [captureMode, triggerPhotoCapture, triggerVideoRecording]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleMainCapture();
      } else if (e.key === 'Escape') {
        if (overlayMode !== 'normal') {
          setOverlayMode('normal');
        } else if (isCountingDown) {
          cancelCountdown();
        } else if (isRecording) {
          stopVideoRecording();
        }
      } else if (e.key.toLowerCase() === 'o') {
        setOverlayMode((prev) => getNextOverlayMode(prev));
      } else if (e.key.toLowerCase() === 'b') {
        setOverlayMode((prev) => (prev === 'black' ? 'normal' : 'black'));
      } else if (e.key.toLowerCase() === 'w') {
        setOverlayMode((prev) => (prev === 'white' ? 'normal' : 'white'));
      } else if (e.key.toLowerCase() === 'h') {
        setButtonVisibility((prev) =>
          prev === 'visible' ? 'hidden' : prev === 'hidden' ? 'minimal' : 'visible'
        );
      } else if (e.key.toLowerCase() === 't') {
        setIsTimerModalOpen((prev) => !prev);
      } else if (e.key.toLowerCase() === 'v') {
        setCaptureMode('video');
      } else if (e.key.toLowerCase() === 'p') {
        setCaptureMode('photo');
      } else if (e.key === 'Shift') {
        setIsPeeking(true);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Shift') {
        setIsPeeking(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [
    handleMainCapture,
    overlayMode,
    isCountingDown,
    isRecording,
    cancelCountdown,
    stopVideoRecording,
  ]);

  // Fullscreen toggle
  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  // Delete media item
  const handleDeleteItem = async (id: string) => {
    await deleteMediaItem(id);
    setMediaList((prev) => prev.filter((i) => i.id !== id));
  };

  // Clear all media
  const handleClearAll = async () => {
    await clearAllMedia();
    setMediaList([]);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black text-white flex flex-col font-sans select-none">
      {/* Top Header Bar */}
      <HeaderBar
        overlayMode={overlayMode}
        onSetOverlayMode={setOverlayMode}
        buttonVisibility={buttonVisibility}
        onSetButtonVisibility={setButtonVisibility}
        settings={timerSettings}
        onOpenTimerSettings={() => setIsTimerModalOpen(true)}
        micEnabled={micEnabled}
        onToggleMic={() => setMicEnabled(!micEnabled)}
        onToggleSound={() =>
          setTimerSettings((prev) => ({ ...prev, soundFeedback: !prev.soundFeedback }))
        }
        isSimulated={isSimulated}
        onToggleSimulated={() => {
          if (isSimulated) {
            startCamera(false);
          } else {
            startSimulatedFeed();
          }
        }}
        onFlipCamera={toggleFacingMode}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onToggleFullscreen={handleToggleFullscreen}
        onOpenAndroidInstall={() => setIsAndroidInstallOpen(true)}
      />

      {/* Main Viewfinder Center */}
      <main className="relative flex-1 w-full h-full flex flex-col overflow-hidden min-h-0">
        <CameraView
          videoRef={videoRef}
          isLive={isLive}
          isSimulated={isSimulated}
          isRecording={isRecording}
          recordingDuration={recordingDuration}
          maxRecordingDuration={timerSettings.videoDurationSeconds}
          isFlashActive={isFlashActive}
          isCountingDown={isCountingDown}
          countdownSeconds={countdownSecondsRemaining}
          onScreenClick={handleMainCapture}
          tapToCaptureEnabled={tapToCapture}
        />

        {/* Bottom Shutter & Controls Dock (only rendered when in normal view) */}
        {overlayMode === 'normal' && (
          <div className="absolute bottom-0 inset-x-0 z-30 pointer-events-auto bg-gradient-to-t from-black/90 via-black/40 to-transparent pt-6">
            <CaptureControls
              mode={captureMode}
              onSetMode={setCaptureMode}
              buttonVisibility={buttonVisibility}
              onSetButtonVisibility={setButtonVisibility}
              onCapture={handleMainCapture}
              isRecording={isRecording}
              recordingDuration={recordingDuration}
              isCountingDown={isCountingDown}
              countdownSeconds={countdownSecondsRemaining}
              settings={timerSettings}
              onOpenTimerSettings={() => setIsTimerModalOpen(true)}
              latestMedia={mediaList.length > 0 ? mediaList[0] : null}
              onOpenGallery={() => setIsGalleryOpen(true)}
              mediaCount={mediaList.length}
            />
          </div>
        )}
      </main>

      {/* Solid Black or Solid White Screen Overlay */}
      <ScreenOverlay
        mode={overlayMode}
        onExitOverlay={() => setOverlayMode('normal')}
        onToggleMode={(newMode) => setOverlayMode(newMode)}
        buttonVisibility={buttonVisibility}
        onToggleCapture={handleMainCapture}
        isRecording={isRecording}
        recordingDuration={recordingDuration}
        captureMode={captureMode}
        isCountingDown={isCountingDown}
        countdownSeconds={countdownSecondsRemaining}
        onPeekStart={() => setIsPeeking(true)}
        onPeekEnd={() => setIsPeeking(false)}
        isPeeking={isPeeking}
        tapToCaptureEnabled={tapToCapture}
      />

      {/* Floating Feedback Toast */}
      {feedbackToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-neutral-900/90 border border-white/20 text-white text-xs font-semibold backdrop-blur-md shadow-2xl flex items-center gap-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>{feedbackToast}</span>
        </div>
      )}

      {/* Modals */}
      <TimerSettingsModal
        isOpen={isTimerModalOpen}
        onClose={() => setIsTimerModalOpen(false)}
        settings={timerSettings}
        onSaveSettings={(newSettings) => setTimerSettings(newSettings)}
        tapToCapture={tapToCapture}
        onToggleTapToCapture={() => setTapToCapture((prev) => !prev)}
      />

      <GalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        items={mediaList}
        onDeleteItem={handleDeleteItem}
        onClearAll={handleClearAll}
      />

      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      <AndroidInstallModal
        isOpen={isAndroidInstallOpen}
        onClose={() => setIsAndroidInstallOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        onTriggerInstall={triggerInstallPrompt}
      />
    </div>
  );
}
