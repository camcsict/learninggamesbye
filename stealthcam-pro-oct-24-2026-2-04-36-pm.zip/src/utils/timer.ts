/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ScreenOverlayMode = 'normal' | 'black' | 'white';
export type ButtonVisibilityMode = 'visible' | 'hidden' | 'minimal';
export type CaptureMode = 'photo' | 'video';

export interface TimerSettings {
  photoCountdownSeconds: number; // 0 = off, e.g. 3, 5, 10
  videoDelaySeconds: number;     // 0 = off, e.g. 3, 5
  videoDurationSeconds: number;  // 0 = unlimited, e.g. 15, 30, 60
  soundFeedback: boolean;
  burstCount: number;            // 1 = single shot, 3, 5
  burstIntervalMs: number;       // default 500ms
}

export const DEFAULT_TIMER_SETTINGS: TimerSettings = {
  photoCountdownSeconds: 0,
  videoDelaySeconds: 0,
  videoDurationSeconds: 0,
  soundFeedback: true,
  burstCount: 1,
  burstIntervalMs: 600,
};

/**
 * Format seconds into mm:ss or hh:mm:ss string
 */
export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const totalSecs = Math.floor(seconds);
  const hrs = Math.floor(totalSecs / 3600);
  const mins = Math.floor((totalSecs % 3600) / 60);
  const secs = totalSecs % 60;

  const pad = (n: number) => n.toString().padStart(2, '0');

  if (hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

/**
 * Calculate completion percentage between 0 and 100
 */
export function calculateProgress(elapsed: number, max: number): number {
  if (max <= 0 || elapsed <= 0) return 0;
  const pct = (elapsed / max) * 100;
  return Math.min(100, Math.max(0, Math.round(pct * 10) / 10));
}

/**
 * Validate and sanitize numeric timer input
 */
export function sanitizeTimerValue(value: number, min: number = 0, max: number = 3600): number {
  if (isNaN(value) || value < min) return min;
  if (value > max) return max;
  return Math.floor(value);
}

/**
 * Get human-readable label for current overlay mode
 */
export function getOverlayLabel(mode: ScreenOverlayMode): string {
  switch (mode) {
    case 'black':
      return 'Solid Black (Stealth)';
    case 'white':
      return 'Solid White (Ring Light)';
    case 'normal':
    default:
      return 'View Screen';
  }
}

/**
 * Cycle through overlay modes: normal -> black -> white -> normal
 */
export function getNextOverlayMode(current: ScreenOverlayMode): ScreenOverlayMode {
  if (current === 'normal') return 'black';
  if (current === 'black') return 'white';
  return 'normal';
}
