import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatDuration,
  calculateProgress,
  sanitizeTimerValue,
  getOverlayLabel,
  getNextOverlayMode,
} from './timer';

test('formatDuration formats 0 and small seconds correctly', () => {
  assert.equal(formatDuration(0), '00:00');
  assert.equal(formatDuration(9), '00:09');
  assert.equal(formatDuration(59), '00:59');
  assert.equal(formatDuration(60), '01:00');
  assert.equal(formatDuration(65), '01:05');
});

test('formatDuration formats hours correctly', () => {
  assert.equal(formatDuration(3600), '01:00:00');
  assert.equal(formatDuration(3665), '01:01:05');
  assert.equal(formatDuration(7200), '02:00:00');
});

test('formatDuration handles invalid and negative input', () => {
  assert.equal(formatDuration(-10), '00:00');
  assert.equal(formatDuration(NaN), '00:00');
});

test('calculateProgress calculates clamped percentages', () => {
  assert.equal(calculateProgress(0, 60), 0);
  assert.equal(calculateProgress(30, 60), 50);
  assert.equal(calculateProgress(60, 60), 100);
  assert.equal(calculateProgress(90, 60), 100);
  assert.equal(calculateProgress(10, 0), 0);
  assert.equal(calculateProgress(-5, 60), 0);
});

test('sanitizeTimerValue validates boundaries and integers', () => {
  assert.equal(sanitizeTimerValue(10, 0, 60), 10);
  assert.equal(sanitizeTimerValue(-5, 0, 60), 0);
  assert.equal(sanitizeTimerValue(120, 0, 60), 60);
  assert.equal(sanitizeTimerValue(15.7, 0, 60), 15);
  assert.equal(sanitizeTimerValue(NaN, 0, 60), 0);
});

test('overlay mode utilities work predictably', () => {
  assert.equal(getOverlayLabel('normal'), 'View Screen');
  assert.equal(getOverlayLabel('black'), 'Solid Black (Stealth)');
  assert.equal(getOverlayLabel('white'), 'Solid White (Ring Light)');

  assert.equal(getNextOverlayMode('normal'), 'black');
  assert.equal(getNextOverlayMode('black'), 'white');
  assert.equal(getNextOverlayMode('white'), 'normal');
});
