/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CapturedMedia {
  id: string;
  type: 'photo' | 'video';
  url: string; // Object URL or data URL
  blob?: Blob;
  name: string;
  timestamp: number;
  duration?: number; // in seconds for videos
  width?: number;
  height?: number;
  sizeBytes?: number;
}

const DB_NAME = 'StealthCamProDB';
const STORE_NAME = 'captures';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveMediaItem(item: CapturedMedia): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    // IndexedDB supports storing Blobs directly
    const record = {
      id: item.id,
      type: item.type,
      blob: item.blob,
      name: item.name,
      timestamp: item.timestamp,
      duration: item.duration,
      width: item.width,
      height: item.height,
      sizeBytes: item.sizeBytes || item.blob?.size || 0,
    };

    store.put(record);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('Failed to save to IndexedDB, fallback active:', err);
  }
}

export async function loadMediaItems(): Promise<CapturedMedia[]> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();

    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const records = request.result || [];
        const items: CapturedMedia[] = records.map((rec: {
          id: string;
          type: 'photo' | 'video';
          blob?: Blob;
          name: string;
          timestamp: number;
          duration?: number;
          width?: number;
          height?: number;
          sizeBytes?: number;
        }) => {
          let url = '';
          if (rec.blob) {
            url = URL.createObjectURL(rec.blob);
          }
          return {
            id: rec.id,
            type: rec.type,
            url,
            blob: rec.blob,
            name: rec.name,
            timestamp: rec.timestamp,
            duration: rec.duration,
            width: rec.width,
            height: rec.height,
            sizeBytes: rec.sizeBytes,
          };
        });
        // Sort newest first
        items.sort((a, b) => b.timestamp - a.timestamp);
        resolve(items);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to load from IndexedDB:', err);
    return [];
  }
}

export async function deleteMediaItem(id: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.delete(id);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('Failed to delete item from IndexedDB:', err);
  }
}

export async function clearAllMedia(): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('Failed to clear IndexedDB:', err);
  }
}
