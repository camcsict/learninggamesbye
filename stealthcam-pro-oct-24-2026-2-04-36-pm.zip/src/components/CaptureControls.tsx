/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Camera,
  Video,
  Square,
  Clock,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Sliders,
} from 'lucide-react';
import {
  CaptureMode,
  ButtonVisibilityMode,
  TimerSettings,
  formatDuration,
} from '../utils/timer';
import { CapturedMedia } from '../utils/storage';

interface CaptureControlsProps {
  mode: CaptureMode;
  onSetMode: (mode: CaptureMode) => void;
  buttonVisibility: ButtonVisibilityMode;
  onSetButtonVisibility: (vis: ButtonVisibilityMode) => void;
  onCapture: () => void;
  isRecording: boolean;
  recordingDuration: number;
  isCountingDown: boolean;
  countdownSeconds: number;
  settings: TimerSettings;
  onOpenTimerSettings: () => void;
  latestMedia: CapturedMedia | null;
  onOpenGallery: () => void;
  mediaCount: number;
}

export const CaptureControls: React.FC<CaptureControlsProps> = ({
  mode,
  onSetMode,
  buttonVisibility,
  onSetButtonVisibility,
  onCapture,
  isRecording,
  recordingDuration,
  isCountingDown,
  countdownSeconds,
  settings,
  onOpenTimerSettings,
  latestMedia,
  onOpenGallery,
  mediaCount,
}) => {
  const isVideo = mode === 'video';

  const timerSummaryText = isVideo
    ? settings.videoDurationSeconds > 0
      ? `Limit: ${formatDuration(settings.videoDurationSeconds)}`
      : settings.videoDelaySeconds > 0
      ? `Delay: ${settings.videoDelaySeconds}s`
      : 'Timer Off'
    : settings.photoCountdownSeconds > 0
    ? `Timer: ${settings.photoCountdownSeconds}s`
    : 'Timer Off';

  return (
    <div className="relative w-full max-w-xl mx-auto flex flex-col items-center gap-4 px-4 pb-6 pt-2 select-none">
      {/* Mode Switcher Pill */}
      <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md p-1 rounded-full border border-white/10 shadow-lg">
        <button
          type="button"
          onClick={() => !isRecording && onSetMode('photo')}
          disabled={isRecording}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
            !isVideo
              ? 'bg-white text-black shadow-md'
              : 'text-neutral-400 hover:text-white'
          } ${isRecording ? 'opacity-40 cursor-not-allowed' : ''}`}
          aria-label="Switch to Photo mode"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>PHOTO</span>
        </button>

        <button
          type="button"
          onClick={() => !isRecording && onSetMode('video')}
          disabled={isRecording}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
            isVideo
              ? 'bg-red-600 text-white shadow-md'
              : 'text-neutral-400 hover:text-white'
          } ${isRecording ? 'opacity-40 cursor-not-allowed' : ''}`}
          aria-label="Switch to Video mode"
        >
          <Video className="w-3.5 h-3.5" />
          <span>VIDEO</span>
        </button>
      </div>

      {/* Main Action Bar */}
      <div className="w-full flex items-center justify-between gap-4">
        {/* Gallery / Recent Media Button */}
        <div className="w-20 flex justify-start">
          <button
            type="button"
            onClick={onOpenGallery}
            className="group relative w-12 h-12 rounded-xl bg-neutral-900/80 border border-white/20 backdrop-blur-md overflow-hidden flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-md"
            aria-label={`Open Gallery (${mediaCount} items)`}
          >
            {latestMedia ? (
              latestMedia.type === 'video' ? (
                <div className="relative w-full h-full flex items-center justify-center bg-black">
                  <video
                    src={latestMedia.url}
                    className="w-full h-full object-cover"
                    muted
                    playsInline
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <Video className="w-4 h-4 text-white" />
                  </div>
                </div>
              ) : (
                <img
                  src={latestMedia.url}
                  alt="Latest photo"
                  className="w-full h-full object-cover"
                />
              )
            ) : (
              <ImageIcon className="w-5 h-5 text-neutral-400 group-hover:text-white" />
            )}
            {mediaCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-sky-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center ring-2 ring-black">
                {mediaCount > 9 ? '9+' : mediaCount}
              </span>
            )}
          </button>
        </div>

        {/* Shutter Button Zone */}
        <div className="flex-1 flex flex-col items-center justify-center">
          {buttonVisibility === 'visible' && (
            <div className="relative flex items-center justify-center">
              {/* Outer pulsing ring for video recording */}
              {isRecording && (
                <div className="absolute inset-0 rounded-full border-4 border-red-500 animate-ping opacity-60" />
              )}

              <button
                type="button"
                data-testid="main-shutter-button"
                onClick={onCapture}
                aria-label={
                  isVideo
                    ? isRecording
                      ? 'Stop Recording'
                      : 'Start Video Recording'
                    : 'Take Photo'
                }
                className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-200 active:scale-95 shadow-2xl ${
                  isVideo
                    ? isRecording
                      ? 'bg-red-600 ring-4 ring-red-400 ring-offset-2 ring-offset-black'
                      : 'bg-red-600 ring-4 ring-white/80 ring-offset-2 ring-offset-black hover:bg-red-500'
                    : 'bg-white ring-4 ring-white/60 ring-offset-2 ring-offset-black hover:bg-neutral-100'
                }`}
              >
                {isVideo ? (
                  isRecording ? (
                    <Square className="w-7 h-7 text-white fill-white rounded-sm" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-white" />
                    </div>
                  )
                ) : (
                  <div className="w-16 h-16 rounded-full border-2 border-black/10 flex items-center justify-center">
                    <Camera className="w-7 h-7 text-neutral-800" />
                  </div>
                )}
              </button>
            </div>
          )}

          {buttonVisibility === 'minimal' && (
            <button
              type="button"
              data-testid="minimal-shutter-button"
              onClick={onCapture}
              aria-label={isVideo ? 'Toggle Video' : 'Snap Photo'}
              className={`w-10 h-10 rounded-full flex items-center justify-center border border-white/30 backdrop-blur-md shadow-lg active:scale-90 transition-all ${
                isVideo
                  ? isRecording
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'bg-red-600/60 text-white hover:bg-red-600'
                  : 'bg-white/70 text-black hover:bg-white'
              }`}
            >
              {isVideo ? (
                isRecording ? (
                  <Square className="w-4 h-4 fill-current" />
                ) : (
                  <Video className="w-4 h-4" />
                )
              ) : (
                <Camera className="w-4 h-4" />
              )}
            </button>
          )}

          {buttonVisibility === 'hidden' && (
            <div
              data-testid="hidden-shutter-zone"
              onClick={onCapture}
              className="px-4 py-2 rounded-xl bg-neutral-900/60 border border-white/10 backdrop-blur-md text-center cursor-pointer hover:bg-neutral-900/80 transition-colors"
            >
              <span className="text-xs text-neutral-400 block font-medium">
                Shutter Hidden • Tap here or press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono text-[10px]">Space</kbd>
              </span>
            </div>
          )}

          {/* Quick status label */}
          <span className="text-[11px] font-mono tracking-wider text-neutral-400 mt-2">
            {isVideo
              ? isRecording
                ? `REC ${formatDuration(recordingDuration)}`
                : 'RECORD'
              : 'SHUTTER'}
          </span>
        </div>

        {/* Timer Config Trigger */}
        <div className="w-20 flex flex-col items-end gap-2">
          <button
            type="button"
            onClick={onOpenTimerSettings}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border backdrop-blur-md transition-all ${
              (isVideo ? settings.videoDelaySeconds > 0 || settings.videoDurationSeconds > 0 : settings.photoCountdownSeconds > 0)
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-neutral-900/70 border-white/15 text-neutral-300 hover:text-white hover:border-white/30'
            }`}
            title="Configure Timers & Delays"
            aria-label="Open Timer Settings"
          >
            <Clock className="w-3.5 h-3.5" />
            <span className="text-[11px]">{timerSummaryText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
