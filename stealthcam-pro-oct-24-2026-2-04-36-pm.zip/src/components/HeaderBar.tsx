/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Moon,
  Sun,
  Eye,
  EyeOff,
  Clock,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Maximize2,
  HelpCircle,
  Radio,
  Camera,
  RefreshCw,
  Smartphone,
} from 'lucide-react';
import { ScreenOverlayMode, ButtonVisibilityMode, TimerSettings } from '../utils/timer';

interface HeaderBarProps {
  overlayMode: ScreenOverlayMode;
  onSetOverlayMode: (mode: ScreenOverlayMode) => void;
  buttonVisibility: ButtonVisibilityMode;
  onSetButtonVisibility: (vis: ButtonVisibilityMode) => void;
  settings: TimerSettings;
  onOpenTimerSettings: () => void;
  micEnabled: boolean;
  onToggleMic: () => void;
  onToggleSound: () => void;
  isSimulated: boolean;
  onToggleSimulated: () => void;
  onFlipCamera: () => void;
  onOpenShortcuts: () => void;
  onToggleFullscreen: () => void;
  onOpenAndroidInstall: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  overlayMode,
  onSetOverlayMode,
  buttonVisibility,
  onSetButtonVisibility,
  settings,
  onOpenTimerSettings,
  micEnabled,
  onToggleMic,
  onToggleSound,
  isSimulated,
  onToggleSimulated,
  onFlipCamera,
  onOpenShortcuts,
  onToggleFullscreen,
  onOpenAndroidInstall,
}) => {
  return (
    <header className="relative z-30 w-full px-4 py-3 flex flex-wrap items-center justify-between gap-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent backdrop-blur-xs select-none">
      {/* Brand & Overlay Selector */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 mr-2">
          <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-md shadow-red-600/30">
            <Camera className="w-4 h-4" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-sm font-bold tracking-tight text-white leading-none">StealthCam</h1>
            <span className="text-[10px] text-neutral-400 font-medium">Capture & Overlay Studio</span>
          </div>
        </div>

        {/* Screen Overlay Selector Tabs */}
        <div className="flex items-center bg-black/60 border border-white/10 rounded-lg p-1 backdrop-blur-md">
          <button
            type="button"
            onClick={() => onSetOverlayMode('normal')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              overlayMode === 'normal'
                ? 'bg-neutral-800 text-white shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Standard viewfinder screen"
            aria-label="View Screen"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden md:inline">View Screen</span>
          </button>

          <button
            type="button"
            data-testid="toggle-black-overlay"
            onClick={() => onSetOverlayMode('black')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              overlayMode === 'black'
                ? 'bg-neutral-900 border border-indigo-500/50 text-indigo-300 shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Blackout overlay (Stealth capture)"
            aria-label="Solid Black Overlay"
          >
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
            <span>Solid Black</span>
          </button>

          <button
            type="button"
            data-testid="toggle-white-overlay"
            onClick={() => onSetOverlayMode('white')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              overlayMode === 'white'
                ? 'bg-white text-black font-semibold shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Pure white overlay (Selfie softbox / ring light)"
            aria-label="Solid White Overlay"
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span>Solid White</span>
          </button>
        </div>
      </div>

      {/* Control Buttons & Options */}
      <div className="flex items-center gap-1.5">
        {/* Shutter Button Visibility Selector */}
        <div className="flex items-center bg-black/60 border border-white/10 rounded-lg p-1 backdrop-blur-md">
          <span className="text-[10px] text-neutral-400 px-1 hidden lg:inline font-mono">SHUTTER:</span>
          <button
            type="button"
            data-testid="shutter-vis-visible"
            onClick={() => onSetButtonVisibility('visible')}
            className={`px-2 py-1 rounded text-xs font-medium transition-all ${
              buttonVisibility === 'visible'
                ? 'bg-neutral-700 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Always show capture button"
            aria-label="Show Capture Button"
          >
            Show
          </button>
          <button
            type="button"
            data-testid="shutter-vis-hidden"
            onClick={() => onSetButtonVisibility('hidden')}
            className={`px-2 py-1 rounded text-xs font-medium transition-all ${
              buttonVisibility === 'hidden'
                ? 'bg-red-600/80 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Hide capture button completely"
            aria-label="Hide Capture Button"
          >
            Hide
          </button>
          <button
            type="button"
            onClick={() => onSetButtonVisibility('minimal')}
            className={`px-2 py-1 rounded text-xs font-medium transition-all ${
              buttonVisibility === 'minimal'
                ? 'bg-neutral-700 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Minimalist floating dot"
            aria-label="Minimal Capture Button"
          >
            Minimal
          </button>
        </div>

        {/* Timers Button */}
        <button
          type="button"
          onClick={onOpenTimerSettings}
          className="p-2 rounded-lg bg-black/50 border border-white/10 text-neutral-300 hover:text-white hover:border-white/30 transition-all backdrop-blur-md"
          title="Timer & Countdown Configuration"
          aria-label="Configure Timers"
        >
          <Clock className="w-4 h-4 text-amber-400" />
        </button>

        {/* Flip Camera */}
        <button
          type="button"
          onClick={onFlipCamera}
          className="p-2 rounded-lg bg-black/50 border border-white/10 text-neutral-300 hover:text-white hover:border-white/30 transition-all backdrop-blur-md"
          title="Flip Camera (Front/Rear)"
          aria-label="Flip Camera"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        {/* Microphone Toggle */}
        <button
          type="button"
          onClick={onToggleMic}
          className={`p-2 rounded-lg border backdrop-blur-md transition-all ${
            micEnabled
              ? 'bg-black/50 border-white/10 text-neutral-300 hover:text-white'
              : 'bg-red-900/40 border-red-500/40 text-red-400'
          }`}
          title={micEnabled ? 'Microphone Enabled' : 'Microphone Muted'}
          aria-label={micEnabled ? 'Mute Microphone' : 'Unmute Microphone'}
        >
          {micEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
        </button>

        {/* Shutter Sound Toggle */}
        <button
          type="button"
          onClick={onToggleSound}
          className={`p-2 rounded-lg border backdrop-blur-md transition-all ${
            settings.soundFeedback
              ? 'bg-black/50 border-white/10 text-neutral-300 hover:text-white'
              : 'bg-neutral-900 border-neutral-700 text-neutral-500'
          }`}
          title={settings.soundFeedback ? 'Sound Feedback On' : 'Silent / Stealth Sound Off'}
          aria-label={settings.soundFeedback ? 'Disable Sounds' : 'Enable Sounds'}
        >
          {settings.soundFeedback ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Simulated Feed Indicator / Toggle */}
        <button
          type="button"
          onClick={onToggleSimulated}
          className={`px-2 py-1.5 rounded-lg border text-xs font-mono font-medium backdrop-blur-md transition-all flex items-center gap-1 ${
            isSimulated
              ? 'bg-sky-950/60 border-sky-500/50 text-sky-300'
              : 'bg-black/50 border-white/10 text-neutral-400 hover:text-neutral-200'
          }`}
          title="Toggle between Live Hardware Webcam and Simulated Studio Feed"
          aria-label="Toggle Camera Source"
        >
          <Radio className={`w-3.5 h-3.5 ${isSimulated ? 'animate-pulse text-sky-400' : ''}`} />
          <span className="hidden sm:inline">{isSimulated ? 'SIM' : 'CAM'}</span>
        </button>

        {/* Install on Android APK modal trigger */}
        <button
          type="button"
          data-testid="header-install-apk-button"
          onClick={onOpenAndroidInstall}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/80 hover:text-white transition-all backdrop-blur-md text-xs font-semibold shadow-xs"
          title="Install on Android Device / Get .APK"
          aria-label="Install on Android (.APK)"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Install APK</span>
        </button>

        {/* Shortcuts / Help modal */}
        <button
          type="button"
          onClick={onOpenShortcuts}
          className="p-2 rounded-lg bg-black/50 border border-white/10 text-neutral-300 hover:text-white transition-all backdrop-blur-md"
          title="Keyboard shortcuts & gestures"
          aria-label="Help and Shortcuts"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Fullscreen */}
        <button
          type="button"
          onClick={onToggleFullscreen}
          className="p-2 rounded-lg bg-black/50 border border-white/10 text-neutral-300 hover:text-white transition-all backdrop-blur-md hidden sm:flex"
          title="Toggle Fullscreen"
          aria-label="Toggle Fullscreen"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
