/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Grid, Sparkles, ShieldAlert } from 'lucide-react';
import { formatDuration } from '../utils/timer';

interface CameraViewProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  isLive: boolean;
  isSimulated: boolean;
  isRecording: boolean;
  recordingDuration: number;
  maxRecordingDuration: number;
  isFlashActive: boolean;
  isCountingDown: boolean;
  countdownSeconds: number;
  onScreenClick: () => void;
  tapToCaptureEnabled: boolean;
}

export const CameraView: React.FC<CameraViewProps> = ({
  videoRef,
  isLive,
  isSimulated,
  isRecording,
  recordingDuration,
  maxRecordingDuration,
  isFlashActive,
  isCountingDown,
  countdownSeconds,
  onScreenClick,
  tapToCaptureEnabled,
}) => {
  const [showGrid, setShowGrid] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'cover' | 'contain'>('cover');

  return (
    <div
      className="relative flex-1 w-full h-full overflow-hidden bg-neutral-950 flex items-center justify-center select-none"
      onClick={() => {
        if (tapToCaptureEnabled) {
          onScreenClick();
        }
      }}
    >
      {/* Real or Simulated Video stream */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full h-full transition-all duration-300 pointer-events-none ${
          aspectRatio === 'cover' ? 'object-cover' : 'object-contain'
        }`}
      />

      {/* Visual Flash effect upon photo capture */}
      <div
        className={`absolute inset-0 bg-white pointer-events-none z-30 transition-opacity duration-150 ${
          isFlashActive ? 'opacity-90' : 'opacity-0'
        }`}
      />

      {/* Rule of Thirds Grid */}
      {showGrid && (
        <div className="absolute inset-0 pointer-events-none z-10 grid grid-cols-3 grid-rows-3">
          <div className="border-r border-b border-white/20" />
          <div className="border-r border-b border-white/20" />
          <div className="border-b border-white/20" />
          <div className="border-r border-b border-white/20" />
          <div className="border-r border-b border-white/20" />
          <div className="border-b border-white/20" />
          <div className="border-r border-white/20" />
          <div className="border-r border-white/20" />
          <div />
        </div>
      )}

      {/* Countdown Large Visual Display */}
      {isCountingDown && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/40 backdrop-blur-xs pointer-events-none animate-fadeIn">
          <div className="relative flex items-center justify-center">
            {/* Pulsing ring */}
            <div className="w-40 h-40 rounded-full border-4 border-amber-400/30 animate-ping absolute" />
            <div className="w-36 h-36 rounded-full bg-black/80 border-4 border-amber-400 flex items-center justify-center shadow-2xl">
              <span className="text-7xl font-mono font-black text-amber-400 animate-scaleBounce">
                {countdownSeconds}
              </span>
            </div>
          </div>
          <span className="mt-4 px-4 py-1 rounded-full bg-black/70 border border-white/20 text-white text-xs font-mono tracking-widest uppercase">
            Get Ready...
          </span>
        </div>
      )}

      {/* Live Recording HUD Tag */}
      {isRecording && (
        <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/80 border border-red-500/50 backdrop-blur-md shadow-lg">
          <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse" />
          <span className="text-xs font-mono font-bold text-white tracking-wider">
            REC {formatDuration(recordingDuration)}
          </span>
          {maxRecordingDuration > 0 && (
            <span className="text-xs font-mono text-neutral-400">
              / {formatDuration(maxRecordingDuration)}
            </span>
          )}
        </div>
      )}

      {/* Simulated Stream Banner */}
      {isSimulated && (
        <div className="absolute top-4 right-4 z-20 flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-sky-950/80 border border-sky-500/40 text-sky-300 text-[11px] font-mono backdrop-blur-md">
          <Sparkles className="w-3 h-3" />
          <span>Simulated Feed</span>
        </div>
      )}

      {/* Viewfinder utility controls (Grid / Fit) */}
      <div className="absolute bottom-4 right-4 z-20 flex items-center gap-1.5">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setShowGrid((prev) => !prev);
          }}
          className={`p-2 rounded-lg backdrop-blur-md border text-xs transition-colors ${
            showGrid
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
              : 'bg-black/50 border-white/10 text-neutral-400 hover:text-white'
          }`}
          title="Toggle Rule of Thirds Grid"
          aria-label="Toggle Grid"
        >
          <Grid className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setAspectRatio((prev) => (prev === 'cover' ? 'contain' : 'cover'));
          }}
          className="px-2 py-1.5 rounded-lg backdrop-blur-md border border-white/10 bg-black/50 text-[11px] font-mono text-neutral-400 hover:text-white transition-colors"
          title="Toggle Aspect Ratio (Cover / Fit)"
          aria-label="Toggle Aspect Ratio"
        >
          {aspectRatio === 'cover' ? '16:9' : 'FIT'}
        </button>
      </div>

      {/* Viewfinder crosshairs */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-20">
        <div className="w-8 h-8 border border-white rounded-full flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-white rounded-full" />
        </div>
      </div>
    </div>
  );
};
