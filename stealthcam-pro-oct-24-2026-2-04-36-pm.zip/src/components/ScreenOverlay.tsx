/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, X, Camera, Video, Square, Sun, Moon } from 'lucide-react';
import { ScreenOverlayMode, ButtonVisibilityMode, formatDuration } from '../utils/timer';

interface ScreenOverlayProps {
  mode: ScreenOverlayMode;
  onExitOverlay: () => void;
  onToggleMode: (newMode: ScreenOverlayMode) => void;
  buttonVisibility: ButtonVisibilityMode;
  onToggleCapture: () => void;
  isRecording: boolean;
  recordingDuration: number;
  captureMode: 'photo' | 'video';
  isCountingDown: boolean;
  countdownSeconds: number;
  onPeekStart: () => void;
  onPeekEnd: () => void;
  isPeeking: boolean;
  tapToCaptureEnabled: boolean;
}

export const ScreenOverlay: React.FC<ScreenOverlayProps> = ({
  mode,
  onExitOverlay,
  onToggleMode,
  buttonVisibility,
  onToggleCapture,
  isRecording,
  recordingDuration,
  captureMode,
  isCountingDown,
  countdownSeconds,
  onPeekStart,
  onPeekEnd,
  isPeeking,
  tapToCaptureEnabled,
}) => {
  const [showHud, setShowHud] = useState(true);
  const [hudTimeout, setHudTimeout] = useState<number | null>(null);

  // Auto-hide HUD after 4 seconds of inactivity so screen remains solid
  useEffect(() => {
    if (mode === 'normal') return;

    const resetTimer = () => {
      setShowHud(true);
      if (hudTimeout) clearTimeout(hudTimeout);
      const timer = window.setTimeout(() => {
        setShowHud(false);
      }, 4000);
      setHudTimeout(timer);
    };

    resetTimer();
    return () => {
      if (hudTimeout) clearTimeout(hudTimeout);
    };
  }, [mode]);

  if (mode === 'normal') return null;

  const isBlack = mode === 'black';

  return (
    <div
      data-testid="screen-overlay"
      className={`fixed inset-0 z-40 transition-opacity duration-300 select-none ${
        isPeeking ? 'opacity-0 pointer-events-none' : 'opacity-100'
      } ${isBlack ? 'bg-black text-neutral-300' : 'bg-white text-neutral-800'}`}
      onClick={(e) => {
        // If clicking on background and tap-to-capture is enabled
        if (e.target === e.currentTarget) {
          if (tapToCaptureEnabled) {
            onToggleCapture();
          } else {
            setShowHud((prev) => !prev);
          }
        }
      }}
      onDoubleClick={() => onExitOverlay()}
    >
      {/* Discreet floating overlay controls */}
      <div
        className={`absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-full border backdrop-blur-md shadow-2xl transition-all duration-300 ${
          showHud ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
        } ${
          isBlack
            ? 'bg-neutral-900/80 border-neutral-800 text-neutral-200'
            : 'bg-white/90 border-neutral-200 text-neutral-800'
        }`}
      >
        <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider">
          {isBlack ? (
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
          ) : (
            <Sun className="w-3.5 h-3.5 text-amber-500" />
          )}
          {isBlack ? 'Blackout Overlay' : 'Softbox White Overlay'}
        </span>

        {isRecording && (
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-red-600 text-white animate-pulse">
            <span className="w-2 h-2 rounded-full bg-white" />
            REC {formatDuration(recordingDuration)}
          </span>
        )}

        {isCountingDown && (
          <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500 text-black">
            Timer: {countdownSeconds}s
          </span>
        )}

        <div className="h-4 w-px bg-neutral-500/30 mx-1" />

        {/* Switch mode between black / white */}
        <button
          type="button"
          onClick={() => onToggleMode(isBlack ? 'white' : 'black')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
            isBlack
              ? 'hover:bg-neutral-800 text-neutral-300'
              : 'hover:bg-neutral-100 text-neutral-700'
          }`}
          title="Switch overlay color"
          aria-label="Switch overlay color"
        >
          {isBlack ? 'Use White' : 'Use Black'}
        </button>

        {/* Peek button: hold to preview camera */}
        <button
          type="button"
          onMouseDown={onPeekStart}
          onMouseUp={onPeekEnd}
          onTouchStart={onPeekStart}
          onTouchEnd={onPeekEnd}
          className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
            isBlack
              ? 'hover:bg-neutral-800 text-neutral-300'
              : 'hover:bg-neutral-100 text-neutral-700'
          }`}
          title="Hold to peek at camera"
          aria-label="Hold to peek at camera"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Peek</span>
        </button>

        {/* Exit overlay */}
        <button
          type="button"
          onClick={onExitOverlay}
          className="p-1 rounded-md hover:bg-neutral-500/20 text-neutral-400 hover:text-red-500 transition-colors"
          title="Exit overlay to screen view"
          aria-label="Exit overlay"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Capture button if user chose to show it during overlay */}
      {buttonVisibility !== 'hidden' && (
        <div
          className={`absolute bottom-8 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 transition-all duration-300 ${
            showHud ? 'opacity-100 translate-y-0' : 'opacity-20 hover:opacity-100 translate-y-0'
          }`}
        >
          <button
            type="button"
            data-testid="overlay-capture-button"
            onClick={onToggleCapture}
            aria-label={
              captureMode === 'photo'
                ? 'Capture Photo'
                : isRecording
                ? 'Stop Recording'
                : 'Start Recording'
            }
            className={`group relative flex items-center justify-center rounded-full transition-transform active:scale-95 shadow-xl ${
              buttonVisibility === 'minimal'
                ? 'w-12 h-12'
                : 'w-20 h-20 ring-4'
            } ${
              isBlack
                ? captureMode === 'video'
                  ? isRecording
                    ? 'bg-red-600 ring-red-400/40 text-white'
                    : 'bg-red-500/80 ring-neutral-700 text-white'
                  : 'bg-white ring-neutral-700 text-black'
                : captureMode === 'video'
                ? isRecording
                  ? 'bg-red-600 ring-red-300 text-white'
                  : 'bg-neutral-900 ring-neutral-300 text-white'
                : 'bg-neutral-900 ring-neutral-300 text-white'
            }`}
          >
            {captureMode === 'photo' ? (
              <Camera className={buttonVisibility === 'minimal' ? 'w-5 h-5' : 'w-8 h-8'} />
            ) : isRecording ? (
              <Square className={buttonVisibility === 'minimal' ? 'w-4 h-4 fill-current' : 'w-6 h-6 fill-current'} />
            ) : (
              <Video className={buttonVisibility === 'minimal' ? 'w-5 h-5' : 'w-8 h-8'} />
            )}
          </button>
          <span
            className={`text-[11px] font-medium tracking-wide ${
              isBlack ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            {captureMode === 'photo'
              ? 'Tap to Snap'
              : isRecording
              ? 'Tap to Stop'
              : 'Tap to Record'}
          </span>
        </div>
      )}

      {/* When capture button is completely hidden: provide discreet helper or tap zone */}
      {buttonVisibility === 'hidden' && (
        <div
          className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-40 text-center pointer-events-none transition-opacity duration-300 ${
            showHud ? 'opacity-70' : 'opacity-0'
          } ${isBlack ? 'text-neutral-500' : 'text-neutral-400'}`}
        >
          <p className="text-xs">
            Capture Button Hidden • Press <kbd className="px-1.5 py-0.5 rounded border border-current font-mono text-[10px]">Space</kbd> or double-click to capture
          </p>
        </div>
      )}
    </div>
  );
};
