/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Trash2,
  Download,
  Play,
  Pause,
  Image as ImageIcon,
  Video as VideoIcon,
  Calendar,
  Layers,
  ExternalLink,
} from 'lucide-react';
import { CapturedMedia } from '../utils/storage';
import { formatDuration } from '../utils/timer';

interface GalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CapturedMedia[];
  onDeleteItem: (id: string) => void;
  onClearAll: () => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  isOpen,
  onClose,
  items,
  onDeleteItem,
  onClearAll,
}) => {
  const [selectedItem, setSelectedItem] = useState<CapturedMedia | null>(
    items.length > 0 ? items[0] : null
  );

  // Keep selectedItem in sync if items change
  React.useEffect(() => {
    if (items.length > 0 && (!selectedItem || !items.find((i) => i.id === selectedItem.id))) {
      setSelectedItem(items[0]);
    } else if (items.length === 0) {
      setSelectedItem(null);
    }
  }, [items, selectedItem]);

  if (!isOpen) return null;

  const handleDownload = (item: CapturedMedia) => {
    const a = document.createElement('a');
    a.href = item.url;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl h-[85vh] bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-neutral-100">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Capture Gallery</h2>
              <p className="text-xs text-neutral-400">{items.length} captures recorded</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('Delete all captures?')) {
                    onClearAll();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-red-400 hover:bg-red-950/40 border border-red-500/20 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              aria-label="Close gallery"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-neutral-800 flex items-center justify-center text-neutral-500 mb-4">
              <ImageIcon className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">No Captures Yet</h3>
            <p className="text-xs text-neutral-400 max-w-xs">
              Take photos or record videos with or without screen overlays to review and download them here.
            </p>
          </div>
        ) : (
          <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
            {/* Main Preview Area */}
            <div className="flex-1 bg-black flex flex-col items-center justify-center p-4 min-h-0 relative">
              {selectedItem && (
                <div className="w-full h-full flex flex-col items-center justify-center min-h-0">
                  {selectedItem.type === 'photo' ? (
                    <img
                      src={selectedItem.url}
                      alt={selectedItem.name}
                      className="max-w-full max-h-[calc(100%-60px)] object-contain rounded-lg shadow-xl"
                    />
                  ) : (
                    <video
                      key={selectedItem.id}
                      src={selectedItem.url}
                      controls
                      autoPlay
                      className="max-w-full max-h-[calc(100%-60px)] rounded-lg shadow-xl"
                    />
                  )}

                  {/* Metadata & Actions bar */}
                  <div className="w-full max-w-xl flex items-center justify-between gap-3 mt-3 px-2">
                    <div className="min-w-0">
                      <span className="text-xs font-semibold text-white block truncate">
                        {selectedItem.name}
                      </span>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        {new Date(selectedItem.timestamp).toLocaleTimeString()} •{' '}
                        {selectedItem.type === 'video'
                          ? `Duration: ${formatDuration(selectedItem.duration || 0)}`
                          : `${selectedItem.width || 1280}x${selectedItem.height || 720} PNG`}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleDownload(selectedItem)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-500 text-white hover:bg-sky-400 shadow-md transition-all active:scale-95"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteItem(selectedItem.id)}
                        className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-red-400 hover:bg-neutral-700 transition-colors"
                        title="Delete Capture"
                        aria-label="Delete Capture"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Thumbnail Sidebar */}
            <div className="w-full md:w-64 border-t md:border-t-0 md:border-l border-neutral-800 bg-neutral-950/40 p-3 overflow-y-auto space-y-2">
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block px-1">
                Recent Captures ({items.length})
              </span>

              <div className="grid grid-cols-3 md:grid-cols-1 gap-2">
                {items.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedItem(item)}
                    className={`group relative flex items-center gap-2.5 p-1.5 rounded-xl border text-left transition-all ${
                      selectedItem?.id === item.id
                        ? 'bg-neutral-800 border-sky-500/70 ring-1 ring-sky-500'
                        : 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-800/60'
                    }`}
                  >
                    <div className="relative w-14 h-12 rounded-lg bg-black overflow-hidden flex-shrink-0 flex items-center justify-center">
                      {item.type === 'photo' ? (
                        <img
                          src={item.url}
                          alt="thumb"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="relative w-full h-full flex items-center justify-center bg-neutral-800">
                          <VideoIcon className="w-5 h-5 text-neutral-400" />
                          <Play className="w-3 h-3 text-white absolute fill-white" />
                        </div>
                      )}
                      <span className="absolute bottom-0.5 right-0.5 px-1 rounded bg-black/80 text-[9px] font-mono font-bold text-white uppercase">
                        {item.type}
                      </span>
                    </div>

                    <div className="hidden md:block min-w-0 flex-1">
                      <span className="text-xs font-medium text-white block truncate">
                        {item.name}
                      </span>
                      <span className="text-[10px] text-neutral-400 block font-mono">
                        {new Date(item.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {item.duration ? ` • ${formatDuration(item.duration)}` : ''}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
