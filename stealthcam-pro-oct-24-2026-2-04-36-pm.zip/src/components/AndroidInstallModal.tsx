/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Download,
  CheckCircle2,
  ExternalLink,
  QrCode,
  ShieldCheck,
  Copy,
  Check,
} from 'lucide-react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  onTriggerInstall: () => Promise<boolean>;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  onTriggerInstall,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(
    currentUrl
  )}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Generate simple QR code SVG using Google Chart API / QR server
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
    currentUrl
  )}&bgcolor=171717&color=38bdf8`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl text-neutral-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Install on Android (.APK)
              </h2>
              <p className="text-xs text-neutral-400">
                Install directly on phone or package standalone APK
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 overflow-y-auto">
          {/* Method 1: Instant Native Android WebAPK Installation */}
          <div className="p-4 rounded-xl bg-neutral-800/50 border border-neutral-700/80 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">
                  1
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">Direct Android Installation (WebAPK)</h3>
                  <span className="text-[11px] text-emerald-400 font-medium">
                    Recommended • No USB or sideloading needed
                  </span>
                </div>
              </div>
              {isInstalled && (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Installed
                </span>
              )}
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              Android automatically compiles this app into a native system app with full-screen
              viewfinder, camera and mic permissions, home screen icon, and offline support.
            </p>

            {isInstallable ? (
              <button
                type="button"
                data-testid="pwa-install-button"
                onClick={async () => {
                  const installed = await onTriggerInstall();
                  if (installed) onClose();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md active:scale-98"
              >
                <Download className="w-4 h-4" />
                <span>Install StealthCam on this Device</span>
              </button>
            ) : (
              <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-700/60 text-xs text-neutral-300 space-y-1">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-sky-400" />
                  <span>How to install on your Android phone:</span>
                </div>
                <ol className="list-decimal list-inside space-y-0.5 text-neutral-400 text-[11px]">
                  <li>Open this URL in <strong>Google Chrome</strong> or Samsung Internet</li>
                  <li>Tap the <strong>three dots menu (⋮)</strong> at top right</li>
                  <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong></li>
                </ol>
              </div>
            )}
          </div>

          {/* Method 2: Scan QR Code with Android Phone */}
          <div className="p-4 rounded-xl bg-neutral-800/40 border border-neutral-800 flex flex-col sm:flex-row items-center gap-4">
            <div className="w-32 h-32 rounded-xl bg-neutral-950 border border-sky-500/30 p-2 flex items-center justify-center flex-shrink-0">
              <img
                src={qrCodeUrl}
                alt="Scan with phone"
                className="w-full h-full object-contain rounded"
              />
            </div>
            <div className="flex-1 space-y-2 text-center sm:text-left">
              <span className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-sky-400">
                <QrCode className="w-4 h-4" /> Scan with Android Camera
              </span>
              <p className="text-xs text-neutral-400">
                Point your phone's camera at this QR code to open the app on your phone immediately.
              </p>
              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 border border-neutral-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Link Copied!' : 'Copy App URL'}</span>
              </button>
            </div>
          </div>

          {/* Method 3: Generate Standalone .APK File via PWABuilder */}
          <div className="p-4 rounded-xl bg-neutral-800/50 border border-neutral-700/80 space-y-2.5">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-sky-600 text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <div>
                <h3 className="text-sm font-bold text-white">Download Standalone .APK File</h3>
                <span className="text-[11px] text-neutral-400">
                  Generate signed APK or Google Play package via PWABuilder
                </span>
              </div>
            </div>

            <p className="text-xs text-neutral-300">
              Use Microsoft and Google's free <strong>PWABuilder</strong> tool to instantly bundle
              this PWA manifest into a signed Android <code>.apk</code> package file for sideloading.
            </p>

            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-all shadow-md active:scale-98"
            >
              <Download className="w-4 h-4" />
              <span>Generate & Download APK on PWABuilder</span>
              <ExternalLink className="w-3.5 h-3.5 ml-1 opacity-75" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Tested on Android 8 - 15</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-medium bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
