/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Keyboard, Eye, EyeOff, Camera, Video, Sparkles } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Space', desc: 'Trigger shutter (Capture Photo or Start/Stop Video)' },
    { key: 'O', desc: 'Cycle Screen Overlay (Normal → Solid Black → Solid White)' },
    { key: 'B', desc: 'Instantly toggle Solid Black Stealth Overlay' },
    { key: 'W', desc: 'Instantly toggle Solid White Softbox Overlay' },
    { key: 'Esc', desc: 'Exit active overlay back to standard viewfinder' },
    { key: 'H', desc: 'Cycle Capture Button visibility (Show / Hide / Minimal)' },
    { key: 'V / P', desc: 'Switch mode between Photo and Video' },
    { key: 'T', desc: 'Open Timer & Delay settings' },
    { key: 'Shift (Hold)', desc: 'Peek through active overlay to view live camera' },
    { key: 'Double Tap', desc: 'Quick exit overlay or awaken stealth HUD' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl text-neutral-100 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Shortcuts & Discreet Controls</h2>
              <p className="text-xs text-neutral-400">Control camera without touching on-screen buttons</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of shortcuts */}
        <div className="p-5 space-y-2.5 overflow-y-auto max-h-[60vh]">
          {shortcuts.map((s, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between gap-3 p-2 rounded-xl bg-neutral-800/40 border border-neutral-800"
            >
              <span className="text-xs text-neutral-300 font-medium">{s.desc}</span>
              <kbd className="px-2 py-1 rounded-md bg-neutral-800 border border-neutral-700 text-xs font-mono font-bold text-sky-300 shadow-xs whitespace-nowrap">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="px-5 py-3 border-t border-neutral-800 bg-neutral-950/40 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-medium bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
