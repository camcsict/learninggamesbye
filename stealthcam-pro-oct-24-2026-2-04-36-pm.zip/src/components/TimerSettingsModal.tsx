/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Clock, Camera, Video, Volume2, VolumeX, Sparkles, Check } from 'lucide-react';
import { TimerSettings, sanitizeTimerValue } from '../utils/timer';

interface TimerSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TimerSettings;
  onSaveSettings: (settings: TimerSettings) => void;
  tapToCapture: boolean;
  onToggleTapToCapture: () => void;
}

export const TimerSettingsModal: React.FC<TimerSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  tapToCapture,
  onToggleTapToCapture,
}) => {
  const [photoTimer, setPhotoTimer] = useState<number>(settings.photoCountdownSeconds);
  const [videoDelay, setVideoDelay] = useState<number>(settings.videoDelaySeconds);
  const [videoDuration, setVideoDuration] = useState<number>(settings.videoDurationSeconds);
  const [burstCount, setBurstCount] = useState<number>(settings.burstCount);
  const [soundFeedback, setSoundFeedback] = useState<boolean>(settings.soundFeedback);

  const [customPhotoInput, setCustomPhotoInput] = useState<string>(
    photoTimer > 10 ? photoTimer.toString() : ''
  );
  const [customVideoDurationInput, setCustomVideoDurationInput] = useState<string>(
    videoDuration > 300 || (videoDuration > 0 && ![15, 30, 60, 180, 300].includes(videoDuration))
      ? videoDuration.toString()
      : ''
  );

  if (!isOpen) return null;

  const photoPresets = [
    { label: 'Off', val: 0 },
    { label: '2s', val: 2 },
    { label: '3s', val: 3 },
    { label: '5s', val: 5 },
    { label: '10s', val: 10 },
  ];

  const videoDelayPresets = [
    { label: 'Instant', val: 0 },
    { label: '3s', val: 3 },
    { label: '5s', val: 5 },
    { label: '10s', val: 10 },
  ];

  const videoDurationPresets = [
    { label: 'No Limit', val: 0 },
    { label: '15s', val: 15 },
    { label: '30s', val: 30 },
    { label: '1m', val: 60 },
    { label: '3m', val: 180 },
    { label: '5m', val: 300 },
  ];

  const handleApply = () => {
    onSaveSettings({
      photoCountdownSeconds: photoTimer,
      videoDelaySeconds: videoDelay,
      videoDurationSeconds: videoDuration,
      burstCount,
      soundFeedback,
      burstIntervalMs: 600,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl text-neutral-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Timer & Capture Settings</h2>
              <p className="text-xs text-neutral-400">Configure delays, duration limits, and feedback</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-6 overflow-y-auto">
          {/* Photo Timer Section */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                <Camera className="w-4 h-4 text-sky-400" />
                Photo Countdown Timer
              </span>
              <span className="text-xs font-mono font-medium text-amber-400">
                {photoTimer === 0 ? 'Instant' : `${photoTimer}s countdown`}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {photoPresets.map((p) => (
                <button
                  key={p.val}
                  type="button"
                  onClick={() => {
                    setPhotoTimer(p.val);
                    setCustomPhotoInput('');
                  }}
                  className={`py-2 px-1 text-xs font-medium rounded-lg border transition-all ${
                    photoTimer === p.val && !customPhotoInput
                      ? 'bg-amber-500 text-black border-amber-400 font-bold shadow'
                      : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Custom photo seconds */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-xs text-neutral-400">Custom seconds:</span>
              <input
                type="number"
                min="0"
                max="120"
                value={customPhotoInput}
                placeholder="e.g. 15"
                onChange={(e) => {
                  const val = e.target.value;
                  setCustomPhotoInput(val);
                  const parsed = parseInt(val, 10);
                  if (!isNaN(parsed) && parsed >= 0) {
                    setPhotoTimer(sanitizeTimerValue(parsed, 0, 120));
                  }
                }}
                className="w-20 px-2 py-1 bg-neutral-950 border border-neutral-700 rounded-md text-xs font-mono text-white focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="h-px bg-neutral-800" />

          {/* Video Timer Section */}
          <div className="space-y-3">
            <span className="flex items-center gap-1.5 text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              <Video className="w-4 h-4 text-red-500" />
              Video Recording Timers
            </span>

            {/* Video Delay */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>Start Delay Countdown:</span>
                <span className="font-mono text-amber-400 font-medium">
                  {videoDelay === 0 ? 'Instant' : `${videoDelay}s delay`}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {videoDelayPresets.map((p) => (
                  <button
                    key={p.val}
                    type="button"
                    onClick={() => setVideoDelay(p.val)}
                    className={`py-1.5 px-1 text-xs font-medium rounded-lg border transition-all ${
                      videoDelay === p.val
                        ? 'bg-amber-500 text-black border-amber-400 font-bold'
                        : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Video Duration Limit */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>Auto-Stop Duration Limit:</span>
                <span className="font-mono text-red-400 font-medium">
                  {videoDuration === 0 ? 'No Limit' : `${videoDuration}s`}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {videoDurationPresets.map((p) => (
                  <button
                    key={p.val}
                    type="button"
                    onClick={() => {
                      setVideoDuration(p.val);
                      setCustomVideoDurationInput('');
                    }}
                    className={`py-2 px-1 text-xs font-medium rounded-lg border transition-all ${
                      videoDuration === p.val && !customVideoDurationInput
                        ? 'bg-red-600 text-white border-red-500 font-bold shadow'
                        : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* Custom video duration */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-xs text-neutral-400">Custom limit (seconds):</span>
                <input
                  type="number"
                  min="0"
                  max="3600"
                  value={customVideoDurationInput}
                  placeholder="e.g. 45"
                  onChange={(e) => {
                    const val = e.target.value;
                    setCustomVideoDurationInput(val);
                    const parsed = parseInt(val, 10);
                    if (!isNaN(parsed) && parsed >= 0) {
                      setVideoDuration(sanitizeTimerValue(parsed, 0, 3600));
                    }
                  }}
                  className="w-24 px-2 py-1 bg-neutral-950 border border-neutral-700 rounded-md text-xs font-mono text-white focus:outline-none focus:border-red-400"
                />
              </div>
            </div>
          </div>

          <div className="h-px bg-neutral-800" />

          {/* Additional Features: Sound & Screen Tap */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label htmlFor="sound-toggle" className="text-xs font-medium text-neutral-200 block">
                  Audio Feedback (Shutter & Beeps)
                </label>
                <span className="text-[11px] text-neutral-400">
                  Turn off for completely silent stealth capture
                </span>
              </div>
              <input
                id="sound-toggle"
                type="checkbox"
                checked={soundFeedback}
                onChange={(e) => setSoundFeedback(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <label htmlFor="tap-capture-toggle" className="text-xs font-medium text-neutral-200 block">
                  Tap Anywhere on Screen to Capture
                </label>
                <span className="text-[11px] text-neutral-400">
                  Ideal when the capture button is hidden
                </span>
              </div>
              <input
                id="tap-capture-toggle"
                type="checkbox"
                checked={tapToCapture}
                onChange={onToggleTapToCapture}
                className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
              />
            </div>

            {/* Burst Count */}
            <div className="flex items-center justify-between pt-1">
              <div>
                <span className="text-xs font-medium text-neutral-200 block">Burst Shot (Photos)</span>
                <span className="text-[11px] text-neutral-400">Takes multiple rapid shots per shutter</span>
              </div>
              <div className="flex items-center gap-1">
                {[1, 3, 5].map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setBurstCount(cnt)}
                    className={`px-2.5 py-1 text-xs rounded border transition-all ${
                      burstCount === cnt
                        ? 'bg-sky-500 text-white border-sky-400 font-bold'
                        : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                    }`}
                  >
                    {cnt === 1 ? '1x' : `${cnt}x`}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-300 hover:bg-neutral-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            data-testid="apply-timer-settings"
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500 text-black hover:bg-amber-400 shadow-md transition-all active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Apply Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
